import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ServiceService} from '../service.service'

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent {
  allUser: Object;
   userObj={
    name:'',
    mobile:'',
    email:'',
    password:'',
    id:''
  }

  constructor(private serviceService: ServiceService){}

  ngOnInit(){
    this.getLatestUser();
  }
  addUser(formObj: any){
    console.log(formObj)
    this.serviceService.createUser(formObj).subscribe((response)=>{
     this.getLatestUser();
     console.log("add user working ");
    })
   }
 
     getLatestUser(){
      this.serviceService.getallUser().subscribe((response)=>{
        this.allUser=response
        console.log("getLatest working");
      }
      )
         }
  }
  
 
