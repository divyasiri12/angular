import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent  {

 
  isEdit=false;
  userObj={
    name:'',
    mobile:'',
    email:'',
    password:'',
    id:''
  }
  allUser: Object;
  constructor(private serviceService: ServiceService){}
  ngOnInit(){
    this.getLatestUser();
  }
  getLatestUser(){
    this.serviceService.getallUser().subscribe((response)=>{
      this.allUser=response
      console.log("getLatest working");
    }
    )
       }
  editUser(user){
    this.isEdit=true;
    this.userObj= user;
  }

  deleteUser(user){
    this.serviceService.deleteUser(user).subscribe(()=>{
      this.getLatestUser();
    }
    );
   }
    updateUser(){
      this.isEdit=!this.isEdit;
      this.serviceService.updateUser(this.userObj).subscribe(()=>{
       this.getLatestUser()
      })
    }
   
 
   }


  
    
   
 


